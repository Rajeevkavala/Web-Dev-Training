// JavaScript for Day 5 Assignment 1: Smooth Scrolling and Active Link Highlighting
