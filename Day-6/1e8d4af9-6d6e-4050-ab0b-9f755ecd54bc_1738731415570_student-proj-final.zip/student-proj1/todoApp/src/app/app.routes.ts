import { Routes } from '@angular/router';
import { AppComponent } from './app.component';

import { authGuard } from './guards/auth/auth.guard';

export const routes: Routes = [
   
            // {
            //     path: 'home',
            //     component: HomeComponent,
            //     canActivate: [authGuard]
            // },
            // {
            //     path: 'contact',
            //     component: ContactComponent
            // }
        
    
  
   


];
